'use strict';

/**
 * world-city router.
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::world-city.world-city');
