'use strict';

/**
 *  world-city controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::world-city.world-city');
